package org.cvtc.shapes;

public interface Dialog {
	
	public int show(String message, String title);

	
}
