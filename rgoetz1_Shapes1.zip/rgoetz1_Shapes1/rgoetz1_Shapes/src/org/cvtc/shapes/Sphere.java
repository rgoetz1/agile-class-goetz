/**
 * 
 */
package org.cvtc.shapes;

import java.awt.Component;

import javax.swing.JOptionPane;

/**
 * @author Ryan
 *
 */
public class Sphere extends Shape {

	public float radius = 0;

	//Getters and Setters
	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	//Constructor
	public Sphere(float radius) {
		this.radius = radius;
	}

	//Surface Area
	public float surfaceArea() {
		
		float surfaceArea = (float) (4 * Math.PI * (radius * radius));
		return surfaceArea;
	}
	
	//Volume
	public float volume() {
		float volume = (float) (4 / 3 * Math.PI * (radius * radius * radius));
		return volume;
	}
	
	

	@Override
	public void render() {
		// TODO Auto-generated method stub
		Component frame = null;
		
		JOptionPane.showMessageDialog(frame, "The surface area of this sphere is " + this.surfaceArea() + "\nThe volume of the sphere is " + this.volume(), "Sphere", JOptionPane.PLAIN_MESSAGE);
	}
	

	
	

}
