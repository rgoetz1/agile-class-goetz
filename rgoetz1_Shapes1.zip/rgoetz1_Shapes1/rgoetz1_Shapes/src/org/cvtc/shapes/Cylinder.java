/**
 * 
 */
package org.cvtc.shapes;

import java.awt.Component;

import javax.swing.JOptionPane;

/**
 * @author Ryan
 *
 */
public class Cylinder extends Shape {

	private float radius = 0;
	private float height = 0;
	
	//Constructor
	public Cylinder(float radius, float height) {
		this.radius = radius;
		this.height = height;
	}
	
	//Getters and Setters
	public float getRadius() {
		return radius;
	}
	public void setRadius(float radius) {
		this.radius = radius;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}


	

	//Surface Area
	public float surfaceArea() {
		float surfaceArea = (float) (2 * Math.PI * radius * height + (2 * Math.PI) * (radius * radius));
		
		return surfaceArea;
	}
	
	
	//Volume
	public float volume() {
		
		float volume = (float) (Math.PI * (radius * radius) * height);
		return volume;
		
	}
	
	
	@Override
	public void render() {
		// TODO Auto-generated method stub
		Component frame = null;
		
		//Dialog
		JOptionPane.showMessageDialog(frame, "The surface area of this cylinder is " + this.surfaceArea() + "\nThe volume of the cylinder is " + this.volume(), "Cylinder", JOptionPane.PLAIN_MESSAGE);
	}
	
	
	
	
}
