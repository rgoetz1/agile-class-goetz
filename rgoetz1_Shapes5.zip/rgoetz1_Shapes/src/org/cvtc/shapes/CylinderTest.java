package org.cvtc.shapes;

import static org.junit.Assert.*;

import org.junit.Test;

public class CylinderTest {

	MessageBoxSub message = new MessageBoxSub();
	
	Cylinder cylinder1 = new Cylinder(1,1, message);
	Shape cylinder2;
	
	@Test
	public void testCylConstructor() {
		
		cylinder2 = new Cylinder(1,-1, message);
		
		assertTrue(cylinder2 instanceof Cylinder);
	}

	
	@Test
	public void testGetCylRadius() {
		
		assertEquals(1.0, cylinder1.getRadius(), 0.0);
	}
	
	@Test
	public void testGetCylHeight() {
		
		assertEquals(1.0, cylinder1.getHeight(), 0.0);
	}
	
	@Test
	public void testSurfaceArea() {
		assertEquals(12.566370964050293, cylinder1.surfaceArea(), 0.0);
	}
	
	@Test
	public void testVolume() {
		assertEquals(3.1415927410125732, cylinder1.volume(), 0.0);
	}
	
	
	// test render
	@Test
	public void testRender() {
		cylinder1.render();
	}

}
