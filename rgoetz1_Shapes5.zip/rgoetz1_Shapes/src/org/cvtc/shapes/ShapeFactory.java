package org.cvtc.shapes;

public class ShapeFactory {

	private Dialog dialog;

	
	// Constructor
	public ShapeFactory(Dialog dialog) {
		super();
		this.dialog = dialog;
	}
	
	
	
	//Getters and Setters
	private Dialog getDialog() {
		return dialog;
	}
	
	private void setDialog(Dialog dialog) {
		this.dialog = dialog;
	}
	
	
	
	
	// Make Method
	public Shape make(ShapeType type){
		
		if(type == null){
			return null;
		}
		
		if (type == ShapeType.Cylinder){
			return new Cylinder(1, 2, this.dialog);
			
		} else if (type == ShapeType.Cuboid){
			return new Cuboid(1, 2, 1, this.dialog);
			
		} else if (type == ShapeType.Sphere){
			return new Sphere(2, this.dialog);
		}
			
		return null;
		
	};
	
	
}
