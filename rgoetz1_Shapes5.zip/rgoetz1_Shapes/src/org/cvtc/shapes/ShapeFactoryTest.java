package org.cvtc.shapes;

import static org.junit.Assert.*;

import org.junit.Test;

public class ShapeFactoryTest {

	MessageBoxSub messageBoxSub = new MessageBoxSub();
	
	ShapeFactory shapeFactory = new ShapeFactory(messageBoxSub);
	
	
	@Test
	public void testCuboid() {
		
		Cuboid cuboid = new Cuboid(0, 0, 0, messageBoxSub);
		
		assertTrue(cuboid instanceof Cuboid);
	}

	
	@Test
	public void testCylinder() {
		
		Cylinder cylinder = new Cylinder(0, 0, messageBoxSub);
		
		assertTrue(cylinder instanceof Cylinder);
	}

	
	@Test
	public void testSphere() {
		
		Sphere sphere = new Sphere(0, messageBoxSub);
		
		assertTrue(sphere instanceof Sphere);
	}

	
}
