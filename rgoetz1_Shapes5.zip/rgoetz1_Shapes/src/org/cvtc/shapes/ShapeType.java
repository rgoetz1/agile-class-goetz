package org.cvtc.shapes;

public enum ShapeType {

	Cuboid, Cylinder, Sphere;


	}
	
;
