/**
 * 
 */
package org.cvtc.shapes;

/**
 * @author Ryan
 *
 */
public abstract class Shape {

	private Dialog messageBox;
	
	// Constructor
	public Shape(Dialog messageBox) {
		setMessageBox(messageBox);
	};
	
	protected Dialog getMessageBox() {
		return messageBox;
	}
	
	
	@SuppressWarnings("unused")
	private void setMessageBox(Dialog messageBox) {
		this.messageBox = messageBox;
	}
	
	
	public abstract float surfaceArea();
	public abstract float volume();

}
