package org.cvtc.shapes;

import javax.swing.JOptionPane;

public class MessageBoxSub implements Dialog {

	public MessageBoxSub () {
		
	};
	
	
	public int show(String message, String title) {

		return 0x00;
	}
	
}
