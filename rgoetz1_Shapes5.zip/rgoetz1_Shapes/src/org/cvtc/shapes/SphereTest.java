package org.cvtc.shapes;

import static org.junit.Assert.*;

import org.junit.Test;

public class SphereTest {

	MessageBoxSub message = new MessageBoxSub();
	
	Sphere sphere1 = new Sphere(3, message);
	Shape sphere2;
	
	@Test
	public void testConstructor() {
		
		sphere2 = new Sphere(-1, message);
		
		assertTrue(sphere2 instanceof Sphere);
	}

	
	@Test
	public void testGetSphereRadius() {
		
		assertEquals(3.0, sphere1.getRadius(), 0.0);
	}

	@Test
	public void testSurfaceArea() {
		assertEquals(113.09733581542969, sphere1.surfaceArea(), 0.0);
	}
	
	@Test
	public void testVolume() {
		assertEquals(84.822998046875, sphere1.volume(), 0.0);
	}
	
	// test render
	@Test
	public void testRender() {
		sphere1.render();
	}
	
}
