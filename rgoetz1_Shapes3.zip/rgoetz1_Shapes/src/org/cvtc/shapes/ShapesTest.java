package org.cvtc.shapes;

import java.awt.Component;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class ShapesTest {

	public static void main(String[] args) {
		
		// Variables
		float cuboidHeight;
		float cuboidWidth;
		float cuboidDepth;
		
		float cylinderRadius;
		float cylinderHeight;
		
		float sphereRadius;
		
		Cuboid cuboidTest = new Cuboid(0, 0, 0);
		Cylinder cylinderTest = new Cylinder(0, 0);
		Sphere sphereTest = new Sphere(0);
		
	
		//Scanner 
		Scanner keyboard = new Scanner(System.in);
		
		Component frame = null;

		// user input
		System.out.println("\nEnter the height of the Cuboid:");
		cuboidHeight = keyboard.nextFloat();

		System.out.println("Enter the width of the Cuboid:");
		cuboidWidth = keyboard.nextFloat();
		
		System.out.println("Enter the depth of the Cuboid:");
		cuboidDepth = keyboard.nextFloat();
		
		System.out.println("\nEnter the radius of the Cylinder:");
		cylinderRadius = keyboard.nextFloat();

		System.out.println("Enter the height of the Cylinder:");
		cylinderHeight = keyboard.nextFloat();
		
	
		System.out.println("Sphere\nEnter the radius of the Sphere:");
		sphereRadius = keyboard.nextFloat();


		keyboard.close();

		
		// cuboid validation
		if (cuboidHeight < 0 || cuboidWidth < 0 || cuboidDepth < 0) {
			JOptionPane.showMessageDialog(frame,
				    "Please only enter positive numbers",
				    "Error",
				    JOptionPane.PLAIN_MESSAGE);
		} else {
			cuboidTest.setHeight(cuboidHeight);
			cuboidTest.setWidth(cuboidWidth);
			cuboidTest.setDepth(cuboidDepth);
			
			cuboidTest.render();
		}
		
		
		// cylinder validation
		if (cylinderRadius < 0 || cylinderHeight < 0) {
			JOptionPane.showMessageDialog(frame,
				    "Please only enter positive numbers",
				    "Error",
				    JOptionPane.PLAIN_MESSAGE);
		} else {
			cylinderTest.setRadius(cylinderRadius);
			cylinderTest.setHeight(cylinderHeight);
			
			cylinderTest.render();
		}
		
		
		// sphere validation
		if (sphereRadius < 0) {
			JOptionPane.showMessageDialog(frame,
				    "Please only enter positive numbers",
				    "Error",
				    JOptionPane.PLAIN_MESSAGE);
		} else {
			sphereTest.setRadius(sphereRadius);
			
			sphereTest.render();
			
		}
	
		
	}
}
