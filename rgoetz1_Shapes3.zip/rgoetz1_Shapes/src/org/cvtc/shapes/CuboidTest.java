package org.cvtc.shapes;

import static org.junit.Assert.*;

import org.junit.Test;

public class CuboidTest {

	Cuboid cube1 = new Cuboid(1,1,1);
	Shape cube2;
	
	@Test
	public void testConstructor() {
		
		cube2 = new Cuboid(1,1,-1);
		
		assertTrue(cube2 instanceof Cuboid);
	}

	
	@Test
	public void testGetWidth() {
		
		assertEquals(1.0, cube1.getWidth(), 0.0);
	}
	
	@Test
	public void testGetHeight() {
		
		assertEquals(1.0, cube1.getHeight(), 0.0);
	}
	
	@Test
	public void testGetDepth() {
		
		assertEquals(1.0, cube1.getDepth(), 0.0);
	}
	
	@Test
	public void testSurfaceArea() {
		assertEquals(6.0, cube1.surfaceArea(), 0.0);

	}
	
	@Test 
	public void testVolume() {
		assertEquals(1.0, cube1.volume(), 0.0);
	}
	
	
}
